@include('Secciones.HeaderTop')
	@yield('content')
@include('Secciones.Footer')