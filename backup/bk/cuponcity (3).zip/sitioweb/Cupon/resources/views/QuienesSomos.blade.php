@extends('Body')
@section('titulo', 'Quienes Somos')
@section('content')

       <!-- //***Breadcrumb-section Start***// -->
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB50">
                                <h3><span class="parpadea">Quienes Somos</span></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Breadcrumb-Section End***// -->
        
        <!-- //***coupons-details Start***// -->
        <div class="deals bg padTB60">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="blog marB30">
                                    <div class="col-md-8 col-sm-8 col-xs-12 text-justify">
                                        <h4>Somos Cuponcity</h4>
                                        <p>Una empresa innovadora, creada con la motivación de que veas, sientas y disfrutes tu ciudad de una forma que no conocías. Traemos a ti los mejores descuentos en todos los sectores para que te deleites día a día con ese gusto que no te has dado aún, como ese anhelado viaje, esa deliciosa cena, un sorprendente cambio de look o un súper plan en pareja.</p>
                                        <h4 class="marT30">¿Que nos mueve? </h4>
                                        <p>Ser la primera empresa en el Sur Occidente Colombiano que realmente se interese por ti y por tu bolsillo, no tienes que creernos, solo debes comprobarlo, día a día llevaremos a ti los mejores descuentos solo debes dar clic y empezar a disfrutar!!! <br>
                                        Tu Garantía es obtener el mejor precio, nuestro objetivo: tu satisfacción!!! <br>
                                        Contamos con múltiples canales de comunicación para resolver tus dudas e inquietudes en tiempo real.<br><br>

                                       <b> Nuestra Información empresarial</b><br>
                                        •   www.cuponcity.com.co es un servicio de Cuponcity Colombia<br>
                                        •   Encuéntranos en Cr 6A 23N 29 Ciudad Jardín Popayán Cauca<br>
                                        •   E-mail: info@cuponcity.com.co<br>
                                        o   Teléfono celular y WhatsApp: +5 3118490896 <br>
                                        o   Teléfono fijo: 8337031<br>
                                        •   Chat de servicio al cliente<br><br><br>
                                        </p>

                                        <small>
                                            <b> Limitación de responsabilidad</b><br>
                                            Nuestro sitio Web está desarrollado cumpliendo con estrictos sistemas de control, pese a ello pueden presentarse fallos y/o errores en la plataforma;  Cuponcity Colombia no tendrá responsabilidad alguna por errores y/ o pérdidas generadas por errores cometidos por www.cuponcity.com.co. 
                                            www.cuponcity.com.co contiene enlaces que direccionan a otras páginas web con el fin de facilitar la navegabilidad y consultas en las mismas, Cuponcity Colombia no será bajo ninguna circunstancia responsable de los contenidos que dichos sitios ofrezcan.

                                        </small>

                                    </div>
                                    <div class="col-md-4 col-sm-4 col-xs-12 text-center">
                                        <img src="assets_page/img/logo.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***coupons-details End***// -->
@stop