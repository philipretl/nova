$('#timepicker1').timepicker();
$('#timepicker3').timepicker();

$('#timepicker2').timepicker({
	showMeridian:false,
	maxHours    :24
});